<?php
    $con = mysqli_connect("localhost","root","","agrismart") or die(mysqli_error($con));
?>  